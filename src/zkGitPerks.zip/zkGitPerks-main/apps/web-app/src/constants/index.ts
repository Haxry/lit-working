// @ts-ignore
// eslint-disable-next-line import/prefer-default-export
export const PR_CIRCUIT_ID: string = "8131068d-2680-49f8-b35f-33831cad66e5"
export const ZKBILL_CIRCUIT_ID: string = "8adb34ea-e6fc-4807-a087-d3450f8e05c5"
export const HEROKU_CIRCUIT_ID: string = "2882fdf6-9413-4940-b521-d7943b969a8b"
