const Link = {
    baseStyle: {
        _focus: {
            boxShadow: "none"
        }
    }
}

export default Link
